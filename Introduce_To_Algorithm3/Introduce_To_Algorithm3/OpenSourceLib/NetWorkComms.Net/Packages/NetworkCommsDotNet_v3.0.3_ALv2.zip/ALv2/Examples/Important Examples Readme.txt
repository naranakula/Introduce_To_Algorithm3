Some of the included examples have nuget dependencies that should be detected
by your choice of editor (e.g. Visual Studio) when you open the solution file. 
If you get any example build errors please see the respective packages.config 
to ensure all dependancies have been correctly detected / rebuilt.