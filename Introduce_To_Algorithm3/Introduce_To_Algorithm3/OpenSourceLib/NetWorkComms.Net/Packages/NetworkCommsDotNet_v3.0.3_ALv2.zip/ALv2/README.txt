               
			   
			   
                                _      __        __                                             
                               | | /| / / ___   / / ____ ___   __ _  ___                        
                               | |/ |/ / / -_) / / / __// _ \ /  ' \/ -_)                       
                               |__/|__/  \__/ /_/__\__/ \___//_/_/_/\__/                        
                                             /_  __/ ___                                        
                                              / /   / _ \                                       
   _  __       __                       __   /_/___ \___/                        _  __       __ 
  / |/ / ___  / /_ _    __ ___   ____  / /__ / ___/ ___   __ _   __ _   ___     / |/ / ___  / /_
 /    / / -_)/ __/| |/|/ // _ \ / __/ /  '_// /__  / _ \ /  ' \ /  ' \ (_-< _  /    / / -_)/ __/
/_/|_/  \__/ \__/ |__,__/ \___//_/   /_/\_\ \___/  \___//_/_/_//_/_/_//___/(_)/_/|_/  \__/ \__/ 



Thank you for choosing NetworkComms.Net. We hope it will be the only network library you ever need. We 
want it to work perfectly but in the unlikely event your find something broken please let us know so 
that we can fix it.

Please read the following brief, but important sections:

LICENSING: This project is made available under the Apache License v2. Please see the included LICENSE for more information.

GETTING STARTED: Everything you need to know about getting started with NetworkComms.Net, including a 
short introduction video can be found here http://www.networkcomms.net/getting-started/

SUPPORT & TUTORIALS: For support and tutorials please start here http://www.networkcomms.net/network-library-support/